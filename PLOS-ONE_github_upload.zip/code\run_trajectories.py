# -*- coding: utf-8 -*-
"""后台跑30次硅进化，记录每代轨迹，供重绘Figure 2"""
import random, csv, json
import silicon_fast as sf

sf.N_GENERATIONS = 1500
LOAD = 200.0
trajs = []
for r in range(30):
    random.seed(r + 1)
    traj, best = sf.run_evolution("silicon", LOAD, None, r)
    trajs.append(traj)
    print(f"run {r+1}/30 done, final best={traj[-1][2]:.4f}", flush=True)

with open("trajectory_silicon_30.json", "w") as f:
    json.dump(trajs, f)
print("saved trajectory_silicon_30.json", flush=True)
