# -*- coding: utf-8 -*-
"""
Colab rerun script (fast version) for the honest "substrate-mapping / evolutionary
saturation" version of the paper.

Runs 30 silicon + 30 carbon independent evolutions plus a cross-substrate
neutrality control, then writes three CSVs. N_GENERATIONS is reduced from the
original 10,000 to 1,500 (sufficient to observe saturation to the mapping ceiling).
"""
import csv, random, time
import silicon_fast as sf

sf.N_GENERATIONS = 1500
LOAD = 200.0

def run_group(substrate, n=30, out_csv=None):
    rows = []
    for r in range(n):
        random.seed(r + 1)
        t0 = time.time()
        traj, best = sf.run_evolution(substrate, LOAD, None, r)
        s = sf.score_best_entity(best, substrate)
        rows.append({"run_id": r, **s})
        print(f"  [{substrate}] run {r+1:2d}/{n}  {time.time()-t0:5.0f}s  {s}", flush=True)
    with open(out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"  -> wrote {out_csv}", flush=True)
    return rows

t_start = time.time()
print("=== Experiment A: SILICON (30 runs) ===", flush=True)
run_group("silicon", 30, "rerun_silicon.csv")

print("\n=== Experiment B: CARBON (30 runs) ===", flush=True)
run_group("carbon", 30, "rerun_carbon.csv")

print("\n=== Experiment C: NEUTRALITY CONTROL ===", flush=True)
random.seed(1)
_, b_si = sf.run_evolution("silicon", LOAD, None, 1)
random.seed(2)
_, b_c  = sf.run_evolution("carbon",  LOAD, None, 2)
si_as_c = sf.score_best_entity(b_si, "carbon")
c_as_si = sf.score_best_entity(b_c,  "silicon")
with open("rerun_neutrality.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["genome", "scored_substrate", "value"])
    w.writerow(["silicon_best", "carbon", str(si_as_c)])
    w.writerow(["carbon_best", "silicon", str(c_as_si)])
print("  silicon_best scored as carbon:", si_as_c, flush=True)
print("  carbon_best scored as silicon:", c_as_si, flush=True)

print("\n=== SANITY SUMMARY ===", flush=True)
print("total elapsed: %.1f min" % ((time.time() - t_start) / 60), flush=True)
