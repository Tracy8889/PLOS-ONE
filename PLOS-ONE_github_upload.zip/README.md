# Substrate-Mapped Evolutionary Saturation in Digital Organisms — Data & Code

This repository contains the code and data for the manuscript:

> **Substrate-Mapped Evolutionary Saturation in Digital Organisms: Silicon- versus Carbon-Analog Simulation**

## Contents

```
code/
  silicon_fast.py          # Evolutionary algorithm and substrate-mapping model (the simulation)
  colab_rerun_fast.py      # Reproduces the 30 silicon + 30 carbon runs and the cross-substrate control
  run_trajectories.py      # Records per-generation fitness trajectories used for Figure 2
data/
  rerun_silicon.csv        # 30 independent silicon runs (best-evolved entity metrics)
  rerun_carbon.csv         # 30 independent carbon runs
  rerun_neutrality.csv     # Cross-substrate scoring control
  summary_statistics_honest.csv  # Mean ± SD and Welch t-tests for the four reported metrics
  trajectory_silicon_30.json     # 30 per-generation fitness trajectories (Figure 2 source)
figures/
  figure1.png              # EA cycle schematic (300 dpi)
  figure2.png              # Fitness trajectories, real data (300 dpi)
  figure3.png              # Saturation schematic (300 dpi)
```

## Reproducing the results

The results in the manuscript were produced with `silicon_fast.py`. All reported runs use
`N_GENERATIONS = 1500`, a population of 200, and 30 independent random seeds per substrate.

### On a local machine

```bash
python run_trajectories.py          # produces trajectory_silicon_30.json
```

### On Google Colab (recommended, faster)

1. Upload `silicon_fast.py` and `colab_rerun_fast.py` to a Colab notebook
   (or paste each into a cell prefixed with `%%writefile <name>.py`).
2. Run `!python colab_rerun_fast.py`.
3. Download the three `rerun_*.csv` files.

## Note on reproducibility

The four headline metrics reported in an earlier, unpublished version of this work could not be
reproduced from the code that is currently available. The results in this repository — and in the
accompanying manuscript — were therefore regenerated in full from `silicon_fast.py` (the only
version of the simulation code that the authors retain). All figures and statistics in the
manuscript derive directly from the files in this repository.

## License

MIT License. You are free to use, modify, and redistribute this code and data with attribution.
